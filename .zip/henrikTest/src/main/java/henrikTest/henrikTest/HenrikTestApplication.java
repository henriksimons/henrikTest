package henrikTest.henrikTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HenrikTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(HenrikTestApplication.class, args);
	}

}
